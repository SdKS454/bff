package ru.kicksharing.documents.dto.external;

public class UserResponse {
    private String id;
    private String login;
    private String fullName;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
}